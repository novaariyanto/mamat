Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:
* app_mamat-de_DE.po
* app_mamat-id_ID.po
* app_mamat_ES.po
* app_mamat-en_US.po
* app_mamat-de_DE.mo
* app_mamat-id_ID.mo
* app_mamat-es_ES.mo
* app_mamat-en_US.mo
Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
